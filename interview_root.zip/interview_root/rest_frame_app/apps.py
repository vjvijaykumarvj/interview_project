from django.apps import AppConfig


class RestFrameAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'rest_frame_app'
