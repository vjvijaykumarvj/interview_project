from django.contrib import admin
from.models import Database
# Register your models here.
admin.site.register(Database)